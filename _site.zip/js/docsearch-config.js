docsearch({
  apiKey: '41570258d2899056627e035350283111',
  indexName: 'ulyssesmod',
  inputSelector: '.header__search-field',
  debug: false
});

docsearch({
  apiKey: '41570258d2899056627e035350283111',
  indexName: 'ulyssesmod',
  inputSelector: '.navigation__search-field',
  debug: false
});
